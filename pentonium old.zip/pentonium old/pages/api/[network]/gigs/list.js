
import excuteQuery from "../../../../lib/db";

export default async function handler(req, res) {
    if (req.method === 'GET'){
        try {
            let { page, network } = req.query;

            if(!page){
                page = 1;
            }

            const count = 10;



            const result = await excuteQuery({
                query: 'SELECT * FROM `agreements` WHERE `network_id`=? LIMIT ?, ?',
                values: [network, (page - 1) * count,  count]
            });

            
            res.status(200).json({result});
            return 0;
        } catch (error) { 
            res.status(200).json({error: error});
        }
    }
}