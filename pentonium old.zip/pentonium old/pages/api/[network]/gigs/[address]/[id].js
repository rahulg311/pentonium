// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import excuteQuery from '../../../../../lib/db';
import Web3Connection from '../../../../../lib/web3Connection';
import ipfsHandler from '../../../../../lib/ipfsHandler';
import NetworkConfig from "../../../../../config/network";

export default async function handler(req, res) {

    const { address, id, network } = req.query;
    const { listing, agreementToken } = NetworkConfig[network].contracts;

    if (req.method === 'GET'){
        try {

            const result = await excuteQuery({
                query: 'SELECT * FROM agreements WHERE `address`=? AND `agreement_id`=?',
                values: [address, id]
            });
            // return result[0];
            res.status(200).json(result);
        } catch (error) { 
            res.status(200).json(error);
        }
    }else if (req.method === 'POST'){

        // fetch agreement category id
        let category = await new Web3Connection().initializeContract(listing.address, listing.abi).getContract().methods.list(address,id).call();

        if(category == 0) return 0;

        // fetch agreement details from contract
        let data = await new Web3Connection().initializeContract(address, agreementToken.abi).getContract().methods.getAgreementDetails(id).call();

        if(data[2] == "") return 0;

        // fetch data from ipfs storage
        const ipfs_data = await new ipfsHandler().getFileById("QmdHGxj3ngs56qRypqoBaX7cTm4sqqGFJ9rVPGG4DCGB64"); //data[2]

        const findOlder = await excuteQuery({
            query: 'SELECT * from `agreements` WHERE `address`=? AND `agreement_id`=?',
            values: [address, id]
        });

        if(findOlder.length > 0){
            const result = await excuteQuery({
                query: 'UPDATE `agreements` SET `cat_id`=?,  `creator`=?, `owner`=?, `title`=?, `description`=?, `price`=?, `duration`=?, `images`=? WHERE `address`=? AND `agreement_id`=?',
                values: [category, data[5], data[5], "ooooo", "something", data[0], data[1], ipfs_data.images? ipfs_data.images : "[]", address, id]
            });
            res.status(200).json({result});
        }else{
            const result = await excuteQuery({
                query: 'INSERT INTO `agreements` (`cat_id`, `network_id`, `address`, `agreement_id`, `creator`, `owner`, `title`, `description`, `price`, `duration`, `images`) VALUE (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                values: [category, network, address, id, data[5], data[5], "ooooo", "iiiii", data[0], data[1], ipfs_data.images? ipfs_data.images : "[]" ]
            });
            res.status(200).json({result});
        }
        return 0;

    }else{
        res.status(200).json({error: "Method not allowed"});
    }
}

// 0x713eA8602b4aFc2A967486d970f16e4B0c0F2581