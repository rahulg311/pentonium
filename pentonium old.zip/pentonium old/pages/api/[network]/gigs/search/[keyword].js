
import excuteQuery from "../../../../../lib/db";

export default async function handler(req, res) {
    if (req.method === 'GET'){
        try {
            let { page, keyword } = req.query;

            if(!page){
                page = 1;
            }

            const count = 10;

            keyword = '%' + keyword + '%';

            const result = await excuteQuery({
                query: 'SELECT * FROM `agreements` WHERE `title` LIKE ? OR description LIKE ? LIMIT ?, ?',
                values: [keyword, keyword, (page - 1) * count,  count]
            });

            
            res.status(200).json({result});
            return 0;
        } catch (error) { 
            res.status(200).json({error: error});
        }
    }
}