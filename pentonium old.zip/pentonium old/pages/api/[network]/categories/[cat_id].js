
import excuteQuery from "../../../../lib/db";
import Web3Connection from '../../../../lib/web3Connection';
import NetworkConfig from "../../../../config/network";

export default async function handler(req, res) {
    if (req.method === 'GET'){
        try {
            let { cat_id, network } = req.query;

            const { listing, agreementToken } = NetworkConfig[network].contracts;


            const findOlder = await excuteQuery({
                query: 'SELECT * FROM `categories` WHERE `cat_id`=?',
                values: [cat_id]
            });

            if(findOlder.length > 0){
                // const result = await excuteQuery({
                //     query: 'UPDATE `agreements` SET `cat_id`=?,  `creator`=?, `owner`=?, `title`=?, `description`=?, `price`=?, `duration`=?, `images`=? WHERE `address`=? AND `agreement_id`=?',
                //     values: [category, data[5], data[5], "ooooo", "something", data[0], data[1], ipfs_data.images? ipfs_data.images : "[]", address, id]
                // });
                // res.status(200).json({result});
            }else{
                let category = await new Web3Connection().initializeContract(listing.address, listing.abi).getContract().methods.categories(cat_id).call();

                // fetch data from ipfs storage
                const ipfs_data = await new ipfsHandler().getFileById("QmdHGxj3ngs56qRypqoBaX7cTm4sqqGFJ9rVPGG4DCGB64"); //data[2]

                // const result = await excuteQuery({
                //     query: 'INSERT INTO `categories` (`cat_id`, `name`, `metadata`, `image`, `parent_id`) VALUE (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                //     values: [category, address, id, data[5], data[5], "ooooo", "iiiii", data[0], data[1], ipfs_data.images? ipfs_data.images : "[]" ]
                // });

                res.status(200).json({ipfs: category[0]});
            }

            // res.status(200).json({findOlder});
                return 0;
            } catch (error) { 
                res.status(200).json({error: error});
            }
    }
}