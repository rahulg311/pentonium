
import excuteQuery from "../../../../lib/db";

export default async function handler(req, res) {
    if (req.method === 'GET'){
        try {
            let { page, parent_id, network } = req.query;

            if(!page){
                page = 1;
            }

            if(!parent_id){
                parent_id = 0;
            }

            const count = 10;


            const result = await excuteQuery({
                query: 'SELECT * FROM `categories` WHERE `parent_id`=? AND `network_id`=? LIMIT ?, ?',
                values: [parent_id, network, (page - 1) * count,  count]
            });

            
            res.status(200).json({result});
            return 0;
        } catch (error) { 
            res.status(200).json({error: error});
        }
    }
}