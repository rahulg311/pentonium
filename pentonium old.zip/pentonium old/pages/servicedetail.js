import React from "react";
import Header from '../components/Header';
import Footer from '../components/Footer';
import Breadcrumb from '../components/Breadcrumb/Breadcrumb';

import { Tabs, Tab } from "react-bootstrap";

function ServiceDetail() {
    return (<>
        <Header />
        <div className='container mt-3 mb-3'>
            <Breadcrumb />
        </div>

        <section className='client service-section mt-3 mb-3'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-7'>
                        <div className='service_provider'>
                            <div className='provider_detail'>
                                <img className='provider_image' src="https://randomuser.me/api/portraits/men/9.jpg" />
                                <p className='provider_name'> Jim Morgan </p>
                            </div>
                            <div className='provider_contact'>
                                <p> Drop A Message </p>
                                <i className='fa fa-comments-o'></i>
                            </div>
                        </div>

                    </div>
                    <div className='col-md-5'>
                        <div className='service-detail'>
                            <div className='service_rating'>
                                <div className='rating'>
                                    Success Ratio  4.5 /5.0
                                </div>
                                <div className='sold'>
                                    Sold 120 times
                                </div>
                            </div>
                            <div className='service_info'>
                                <h4 className='service_title'>I will design an epic, smooth, accent cartoon character for your comic</h4>

                            </div>
                            <div className='service_price mt-3 mb-3'>
                                <div className='price_title'>
                                    Success Ratio  4.5 /5.0
                                </div>
                                <div className='s_price'>
                                    <sup>$</sup> <span>100</span> USD
                                </div>
                            </div>
                            <div className='service_tab'>
                                <Tabs defaultActiveKey="short_description" id="service_tab">
                                    <Tab eventKey="short_description" title="Short Description">
                                        <p className="mtt-20">1 HQ Ultra Quality Logo Proposal + all desire files Formats for Print + Unlimited Revisions. 1 HQ Ultra Quality Logo Proposal + all desire files Formats for . Read More</p>

                                        <p className="mtt-20">
                                            <div className="d-flex row">
                                                <div className="col-md-6"><i className="fa fa-clock-o"></i> <b>2 Days Delivery</b></div>
                                                <div className="col-md-6"><i className="fa fa-refresh"></i> <b>5 Revisions</b></div>
                                            </div>
                                        </p>
                                    </Tab>
                                    <Tab eventKey="deliverable" title="Deliverables">
                                        Deliverables
                                    </Tab>
                                </Tabs>
                            </div>



                        </div>
                    </div>
                </div>
            </div>
        </section>
        <Footer />
    </>);
}

export default ServiceDetail;