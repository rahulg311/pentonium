const Pagination = () =>{
    return(
        <>
            <div className='row'>
                <div className="col-md-12 col-12">
                <div className='pagination '>
                    <ul className='paginate'>
                        <li className='fa fa-arrow-left fs-13'></li>
                        <li className='active fs-13'>1</li>
                        <li className="fs-13">2</li>
                        <li className="fs-13">3</li>
                        <li>4</li>
                        <li className="fs-13">5</li>
                        <li className="fs-13">.</li>
                        <li className="fs-13">.</li>
                        <li className="fs-13">.</li>
                        <li className='fa fa-arrow-right click fs-13'></li>
                    </ul>
                </div>
                </div>
                
            </div>
        </>
    );
}

export default Pagination;