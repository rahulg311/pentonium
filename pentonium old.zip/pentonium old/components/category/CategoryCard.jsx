import React from 'react'
import { Card } from './card'

export const CategoryCard = () => {
  return (
  <>
  <div className="row my-4">
          <div className="col-md-12">
          <h5 className='f-w-600 fs-28 ms-1'>Explore Design</h5>
          </div>
          
          </div>
          <div className="row my-4">
          <div className="col-md-4 mb-3 mb-3">
          <Card/>
          

          </div>
          <div className="col-md-4 mb-3 ">
          <Card/>
          

          </div>
          <div className="col-md-4 mb-3 ">
          <Card/>
          

          </div>
          <div className="col-md-4 mb-3 mb-3">
          <Card/>
          

          </div>
          <div className="col-md-4 mb-3 ">
          <Card/>
          

          </div>
          <div className="col-md-4 mb-3 ">
          <Card/>
          

          </div>
           </div>

        
         
  </>
  )
}
