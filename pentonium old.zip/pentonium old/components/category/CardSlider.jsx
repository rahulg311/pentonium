import React from 'react'
import { BsCollectionPlayFill } from "react-icons/bs";
import Slider from "react-slick";
import { useRef } from 'react';
export const CardSlider = () => {
  const sliderRef = useRef(null);
  console.log(sliderRef.current);
  var settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
   <>
   <div className="container ">
        <div className="row">
          <div className="col-md-12 col-12 mt-5">
            <h3 className="f-w-600 fs-28 ms-1 mb-4 float-start ">Categories</h3>
          
            <ul className="paginate float-end  mt-2">
              <li className="fa fa-arrow-left fs-13 arrow-r slide-arrow prev-arrow   " onClick={()=>sliderRef.current.slickPrev()}></li>

              <li className="fa fa-arrow-right click fs-13 arrow-r slickkk-next"  onClick={()=>sliderRef.current.slickNext()}></li>
            </ul>
         

          </div>
        </div>

        <div className=" w-100 gap-3">
          <Slider ref={sliderRef} {...settings} >
            <div className="d-flex gap-3 ">
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
            </div>
            <div className="d-flex gap-3 ps-3   ">
              <div className="card   w-8 bg-gray h-86 text-light bg-gray  ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
            </div>
            <div className="d-flex gap-3 ps-3   ">
              <div className="card   w-8 bg-gray h-86 text-light bg-gray  ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
            </div>
            <div className="d-flex gap-3 ps-3   ">
              <div className="card   w-8 bg-gray h-86 text-light bg-gray  ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
            </div>
            <div className="d-flex gap-3 ps-3   ">
              <div className="card   w-8 bg-gray h-86 text-light bg-gray  ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
              <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
                <div className="card-body ">
                  <BsCollectionPlayFill className="bg-dark  ms-3" />
                  <p className="text-dark fs-13 mt-2">Design</p>
                </div>
              </div>
            </div>
          </Slider>
        </div>

        {/* <div className="w-100 d-flex gap-5 ">
           
           <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        </div> */}

        {/* <div className="row">
      
      <div className="col-md-12 d-flex gap-5 ">
           
           <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        <div className="card   w-8 bg-gray h-86 text-light bg-gray ">
          
          <div className="card-body ">
          <BsCollectionPlayFill className="bg-dark  ms-3" />
          <p className="text-dark fs-13 mt-2"  >Design</p>
          </div>
        </div>
        </div>
        
        </div>  */}
      </div>
   </>
  )
}
