import React from 'react'
import { VscArrowRight} from "react-icons/vsc";
import Image from "next/image";

export const Card = () => {
  return (
   <>

          <div className="card    rounded-32 s  ">
            <Image
              src={"/images/Rectangle1.png "}
              alt="Logo"
              width="500px"
              height="400px"
            />
            <div className="card-body">
              <h4 className="card-title fw-bolder fs-23">Logo Designer</h4>
              <p className="card-text fs-16 mt-3">
              Since a logo is the visual entity signifying an organization, logo design is an important area of graphic design. A logo is the central element of a complex identification system that must be functionally extended to all communications of an organization.
              </p>

              {/* <button className="btn btn-dark border-radious ps-5 pe-5">    Explore <VscArrowRight/></button> */}
              <button className="              btnn1">    Explore <VscArrowRight/></button>
            </div>
          </div>
         

        
         
       
   </>
  )
}
