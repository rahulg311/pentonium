const ServiceCard = () => {
    return(
        <div className='col-md-3 mt-3 mb-3'>
            <div className='service_card'>
                <div className='service_banner'>
                    <div className='slider'>
                        <div className='slider_img'>
                            <img src='https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/60b5e3f25f9a6_json_image_1622533106.webp' />
                        </div>
                    </div>
                </div>
                <div className='service_detail p-3'>
                    <p className='company_name'>DesignStudio</p>
                    <h5 className=''>I will digitize logo into embroidery dst pes in 1hr</h5>
                </div>
                <div className='service_price p-3'>
                    <span className='price'> $12 </span>
                    <span className='rating'>
                        <span className='success_rate'> Success Ratio &nbsp; </span>
                        <span className='rate'> 4.5 /5.0 </span>
                    </span>
                </div>
            </div>
        </div>
    );


}
export default ServiceCard;