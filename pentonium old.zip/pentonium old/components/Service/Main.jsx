import React from 'react'

export const Main = () => {
  return (
<>
<div className="container bg-dark rounded-32">
          <div className="row  ">
            <div className="col-md-7 d-flex justify-content-center align-items-center">
              <div className="main px-4 mt-5 mb-4">
                <h1 className="text-white">Want to be a Freelancer</h1>
                <p className="mt-3 text-white text-justfy">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl pretium imperdiet in. Lorem ipsum dolor sit
                  amet, consectetur adipiscing elit. Sed erat egestas nisl
                  pretium imperdiet in.
                </p>
                <button
                  type="button"
                  class="btn btn-outline-light mt-4 rounded-pill ps-5 pe-5 p-2 mb-3"
                >
                  Become an Expert
                </button>
              </div>
            </div>
            <div className="col-md-5 h-278">
              <img className="mt-4" src="./images/cuatee.png" />
            </div>
          </div>
        </div>
</>
  )
}
