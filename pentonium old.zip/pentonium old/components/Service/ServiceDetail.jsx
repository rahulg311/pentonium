const ServiceDetail = () => {
    return(<>
        <div className='row mb-2'>
            <div className='col-md-1 mb-3 col-3'>
                <img className='service_logo' src='https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/60b5e3f25f9a6_json_image_1622533106.webp' />
            </div>
            <div className='col-md-11 col-8 px-4'>
                <h3>Logo Designer</h3>
                <h6>1,358+ Services </h6>
            </div>
        </div>
        <div className='row '>
            <p>Since a logo is the visual entity signifying an organization, logo design is an important area of graphic design. A logo is the central element of a complex identification system that must be functionally extended to all communications of an organization.</p>
        </div>
    </>);
}

export default ServiceDetail;