const ServiceFilter = () => {
    return(<>
        <div className='row'>
            <div className='col-md-6 col-12 row mb-2'>
                <div className='col-md-3 col-6'>
                    <div className='price_dropdown'>
                        <select className='price_select'>
                            <option selected> Price &nbsp; </option>
                        </select>
                    </div>      
                </div>
                <div className='col-md-4 col-6 pe-1' >
                    <div className='price_dropdown'>
                        <select className='price_select'>
                            <option selected> Delivery Time </option>
                        </select>    
                    </div>
                </div>
            </div>
            <div className='col-md-6 sort_section row col-12 '>
               
                <div className='col-md-2 col-12 '>
                    <select className='sort_by d-flex' > 
                    <p className='sort-title'> Sort By :</p>
                        <option selected> Best Seller </option>
                    </select>   
                </div>
            </div>
        </div>
    </>);
}

export default ServiceFilter;