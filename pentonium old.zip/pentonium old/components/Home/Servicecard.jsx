const ServiceCard = () => {
    return (<>
        <div className="col-md-3 mb-4 d-flex justify-content-center">
            <div class="quailty-card h-200">
                <div class="card-body ">
                    <span className="iconcss ">
                        <i class="fa fa-television mt-1" aria-hidden="true"></i>
                    </span>
                  
                       <p className=" fs-16 pp"> Web, Mobile, Software & Dev</p>
                 
                    <div class="cardbottom">
                        1,780+ Services
                    </div>
                </div>
            </div>
        </div>
    </>);
}

export default ServiceCard;