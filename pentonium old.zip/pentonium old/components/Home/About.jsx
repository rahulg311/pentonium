import React from 'react'
import { Aboutit } from './Aboutit'

export const About = () => {
  return (
    <>
    <div className="row pt-3">
            <div className="col-md-12 text-center">
            <div className="title-center mt-7">
                    <h3 className="">What’s Great About It? </h3>
                    <p className="text-muted fw-bolder fs-14 mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl <br/> pretium imperdiet in.</p>
                </div>
              {/* <figure>
                <blockquote class="blockquote">
                  <h2>What’s Great About It? </h2>
                </blockquote>
                <figcaption class="blockquote-footer mt-1 font-bold">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl <br /> pretium imperdiet in.
                </figcaption>
              </figure> */}
            </div>
            <div className="col-md-3 text-center d-flex justify-content-center  align-items-center">
              <Aboutit
                name="Browse Portfolios"
                para="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat egestas nisl pretium imperdiet in. ."
              />
            </div>
            <div className="col-md-3 text-center d-flex justify-content-center  align-items-center">
              <Aboutit
                name="Views Bids"
                para="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat egestas nisl pretium imperdiet in. ."
              />
            </div>
            <div className="col-md-3 text-center d-flex justify-content-center  align-items-center">
              <Aboutit
                name="Live Chat"
                para="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat egestas nisl pretium imperdiet in. ."
              />
            </div>
            <div className="col-md-3 text-center d-flex justify-content-center  align-items-center">
              <Aboutit
                name="Pay For Quality"
                para="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat egestas nisl pretium imperdiet in. ."
              />
            </div>
          </div>
    </>
  )
}
