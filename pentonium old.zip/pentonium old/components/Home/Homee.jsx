import React from 'react'

export const Homee = () => {
  return (
    <>
    <div className="row  ">
            <div className="col-md-6 d-flex justify-content-center align-items-center">
              <div className=" w-483 pt-20">
                <h1 className="f-w-700">Welcome to Work-Sphere</h1>
                <p className="f-w-600 mt-4 text-justfy">
                  Post your gig or get your job done with 360 degree freedom in
                  your work-space with complete data security,ensured by fully
                  transparent Governance.
                </p>
                <span className="p-2 mt-4 sicon  d-flex">
                  <a href="#" className="fs-12">
                    <i className="fa fa-search search_icon  "></i>
                  </a>

                  <p className="serch-click ms-2 mtt-10 text-muted ">
                    Click and Search
                  </p>
                </span>
              </div>
            </div>
            <div className="col-md-6">
              <img src="/images/uservector.png" />
            </div>
            <h5 className="text-dark tp   ">Trusted By</h5>
            <span className="underlineheading"></span>
          </div>
    </>
  )
}
