import React from 'react'



export const Expert = () => {
   
  return (
     
      
    <>

        <div className="row w-100">
       
              <div className="col-md-6 p-0 mb-3">
                <div className=" mt-5 ">
                  <img src="/images/cuate.png" />
                </div>
              </div>
              <div className="col-md-6  d-flex justify-content-center align-items-center">
                <div className=" px-3">
                  <h3>Find an Expert for anything</h3>
                  <p className="mt-4 w-543 w-r-280">
                   <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                    dolor sit amet, consectetur adipiscing elit.”</i>
                  </p>
                  <button className="btn btn-dark border-radious mt-3 ps-5 pe-5 p-2">
                    Join Us
                  </button>
                </div>
              
          
        </div>
      </div>
    </>
  )
}
