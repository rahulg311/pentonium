import React from 'react'

export const Microtectcard = () => {
  return (
    <>
     <div className="card rounded-6 border-r mb-3 w-232 w-r-100 " style={{  }}>
                                    <div className="user one">
                                    </div>

                                    <div className="card-body mt-1">
                                        <h5 className="card-title">Micro Tech</h5>
                                        <p className="card-text fs-14 text-muted">Some quick example text to build on the card .</p>
                                     <div className='row mb-3 '>
                                         <div className='col-12'>
                                         <span className='ux-card'> UI/UX</span>
                                      <span className='ux-card ms-2'> Web Designer</span>
                                         </div>
                                     </div>
                                     <div className='row mb-4'>
                                         <div className='col-12'>
                                         <span className='ux-card'> App Designer</span>
                                      <span className='  p-1 fs-14   '> 18+ service</span>
                                         </div>
                                     </div>
                                      
                                     <button className="  btnn  w-200">Check Portfolio</button>
                                         </div>
                                </div>

    </>
  )
}
