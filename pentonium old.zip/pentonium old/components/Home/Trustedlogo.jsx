const TrustedLogo = ({img}) => {
    return (
        <>
            <div className="box trasted-box">
                <img src={`/images/${img}`} />
            </div>
        </>);
}

export default TrustedLogo;