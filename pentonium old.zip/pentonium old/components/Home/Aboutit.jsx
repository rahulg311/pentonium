import React from 'react'

export const Aboutit = ({ name, para }) => {
    return (
        <>
            <div className="w-205 " >
                <div className="user one">
                    
                </div>

                <div className="card-body p-0 mt-2">
                    <h5 className="card-title mt-1 fw-bolder text-center fs-18">{name}</h5>
                    <h6 className="card-text fs-14 fw-bolder text-muted mt-2 text-center">{para}</h6>



                </div>
            </div>
        </>
    )
}
