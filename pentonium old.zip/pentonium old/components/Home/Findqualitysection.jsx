import ServiceCard from "./servicecard";


const FindQualitySection = () => {
    return (<>
        <section className="client mb-5 back-img1">
            <div className="container">
                <div className="title-center mt-77">
                    <h3 className="">Find Quality Talents</h3>
                    <p className="text-muted fw-bolder fs-14 mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat egestas nisl <br/> pretium imperdiet in.</p>
                </div>
                <div className="row mt-5 pxx-5">
                    <ServiceCard />
                    <ServiceCard />
                    <ServiceCard />
                    <ServiceCard />
                </div>
                <div className="row pxx-5">
                    <ServiceCard />
                    <ServiceCard />
                    <ServiceCard />
                    <ServiceCard />
                </div>
                <p className="bottom-title mt-4 fs-14 mt-5">Don’t get what you are looking for?</p>
                <div className="wrapper">
                    <button className="  btnn">See All Categories</button>
                </div>
            </div>
        </section>
    </>);
}

export default FindQualitySection;