import React from 'react'

export const Quicker = () => {
  return (
   <>
   <div className="row">
            <div className="col-md-12 text-center">
            <div className="title-center mt-7">
                    <h3 className="">Post Projects Quickly Get Responses Even Quicker</h3>
                    <p className="text-muted fw-bolder fs-14 mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl <br/> pretium imperdiet in.</p>
                </div>
            {/* <h3 className="">Post Projects Quickly Get Responses Even Quicker</h3>
                    <p className="text-muted fw-bolder mt-2">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl <br/> pretium imperdiet in.</p> */}
                
              {/* <figure>
                <blockquote class="blockquote">
                  <h2>Post Projects Quickly Get Responses Even Quicker </h2>
                </blockquote>
                <figcaption class="blockquote-footer mt-1">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl pretium imperdiet in.
                </figcaption>
              </figure> */}
            </div>

            <div className="col-md-6">
              <div className="w-quicker w-r-100 mt-5">
                <img src="/images/cuateee.png" />
              </div>
            </div>
            <div className="col-md-6 d-flex justify-content-center align-items-center">
            <div className="w-512 text-justfy w-r-100 mt-5  f-w-600 fs-18 color-b ">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut
                nisi, vitae consectetur purus sapien. Aliquet facilisi at
                faucibus amet, sed faucibus. At arcu sodales pretium ipsum quis.
                Feugiat sociis id adipiscing pulvinar quis erat adipiscing
                mauris non.
                <br />
                <br />
                Odio feugia in in sodales. Iaculis sodales augue nulla
                adipiscing quis massa dignissim massa. Urna malesuada faucibus
                eget sit leo integer tempus. Arcu tempor, et euismod sem.
                Ultrices lobortis at tincidunt ut at. Scelerisque quis at massa
                nunc ut. Egestas vivamus.
                <br />
                <br />
                accumsan eget at felis, enim amet.<br/>
            
             
              <button className="btn btn-dark border-radious mt-5 ps-5 pe-5 p-2">
                Post a project
              </button>
              </div>
            </div>
            
          </div>
   </>
  )
}
