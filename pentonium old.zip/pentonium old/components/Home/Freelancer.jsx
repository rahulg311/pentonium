import React from 'react'
import { Navigation,  Scrollbar, A11y } from 'swiper';

import { Swiper, SwiperSlide } from 'swiper/react';

import Slider from "react-slick";
import { Microtectcard } from './Microtectcard';

export const Freelancer = () => {
  var settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  return (
    <>
    
     <div className="row pt-5">
          <div className="col-md-12 text-center">
            <h2 className="f-w-600">Meet Our Top Expert Freelancer</h2>
            <p className=" h-2 mt-2">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat
              egestas nisl  <br/> pretium imperdiet in.
            </p>
          </div>
          </div>
          <div className="row mt-4 px-5 ">
            {/* <div className="container px-4 "> */}
         
            <Slider {...settings}>
              
            <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>
                <div className="col-md-3 col-lg-3 col-xs-12 col-sm-12 d-flex justify-content-center">
                  <Microtectcard />
                </div>

                </Slider>
                </div>
           
              
              <div className="row mt-4">
                <div className="col-md-12 text-center ">
                  <p className="text-muted">
                    Do you want to join experts? join us
                  </p>
                  <button
                    type="button"
                    class="btn btn-outline-dark rounded-pill ps-5 pe-5 p-2 mb-3"
                  >
                    Become an Expert
                  </button>
                  
                
              </div>
          </div>
    </>
  )
}
