import React from 'react'
import Image from 'next/image'
import { Navigation, Pagination, Scrollbar, A11y } from 'swiper';

import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import Slider from "react-slick";

export const Customer = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  return (
  <>

   <div className="row pt-2">
            <div className="col-md-12 text-center">
            <div className="title-center mt-2">
                    <h3 className="">What Our Customer Are Saying?</h3>
                    <p className="text-muted fw-bolder fs-14 mt-2"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl <br /> pretium imperdiet in.</p>
                </div>
              {/* <figure>
                <blockquote class="blockquote">
                  <h2>What Our Customer Are Saying? </h2>
                </blockquote>
                <figcaption class="blockquote-footer mt-1">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed
                  erat egestas nisl <br /> pretium imperdiet in.
                </figcaption>
              </figure> */}
            </div>
            </div>
   
            
            
            <Slider {...settings}>
            <div className='container'>
            
            <div className="row mt-3 ">
               
               <div className="col-md-6 mt-5 mb-3 ">
                 <div className="w-391 w-r-100 s w-r-100 float-end  me-44">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                         <Image
                           src="/images/facebook.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               <div className="col-md-6 ">
                
                 <div className="w-391 w-r-100 s w-r-100 mss-4">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                       <Image
                           src="/images/shipro.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               </div>
               
               
             
              
                  

           </div>
           <div className='container'>
            
            <div className="row mt-3 ">
               
               <div className="col-md-6 mt-5 mb-3 ">
                 <div className="w-391 w-r-100 s w-r-100 float-end  me-44">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                         <Image
                           src="/images/facebook.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               <div className="col-md-6 ">
                
                 <div className="w-391 w-r-100 s w-r-100 mss-4">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                       <Image
                           src="/images/shipro.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               </div>
               
               
             
              
                  

           </div>
           <div className='container'>
            
            <div className="row mt-3 ">
               
               <div className="col-md-6 mt-5 mb-3 ">
                 <div className="w-391 w-r-100 s w-r-100 float-end  me-44">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                         <Image
                           src="/images/facebook.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               <div className="col-md-6 ">
                
                 <div className="w-391 w-r-100 s w-r-100 mss-4">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                       <Image
                           src="/images/shipro.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               </div>
               
               
             
              
                  

           </div>
           <div className='container'>
            
            <div className="row mt-3 ">
               
               <div className="col-md-6 mt-5 mb-3 ">
                 <div className="w-391 w-r-100 s w-r-100 float-end  me-44">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                         <Image
                           src="/images/facebook.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               <div className="col-md-6 ">
                
                 <div className="w-391 w-r-100 s w-r-100 mss-4">
                   <div className="row mt-3">
                     <div className="col-md-12  ">
                       <div className=" ms-3 mt-3">
                       <Image
                           src="/images/shipro.png"
                           alt="Picture of the author"
                           width={165}
                           height={52}
                         />
                       </div>
                     </div>
                   </div>
 
                   <div className="card-body">
                     <p className="card-text fs-16  f-w-600 text-justfy ps-3 pe-5">
                      <i> “Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                       Sed erat egestas nisl pretium imperdiet in. Lorem ipsum
                       dolor sit amet, consectetur adipiscing elit.”</i>
                     </p>
                   </div>
                   <div className="row mt-3 ">
                     <div className="col-md-3 col-4 ">
                       <div className="user one ms-3"></div>
                     </div>
                     <div className="col-md-8 col-8 pb-3 ">
                       <h4 className="mt-3 fs-18">Jimmy Kolva</h4>
                       <p className="text-muted fs-14">
                         Project Manager at Facebook
                       </p>
                     </div>
                   </div>
                 </div>
               </div>
               </div>
               
               
             
              
                  

           </div>
            </Slider>
           
           
  </>
  )
}
