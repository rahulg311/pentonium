import React from "react";

import { FiCornerUpLeft, FiCornerUpRight, FiBriefcase } from "react-icons/fi";
import { IoIosStarOutline } from "react-icons/io";
import { MessageBox } from "./MessageBox";

export const MessageNav = () => {
  return (
    <>
      <div className="row">
        <div className="col-md-12 d-flex justify-content-between ">
          <div className=" w-50 d-flex">
            <div className=" ">
              <img
                className="service_logo img-circle1 rounded-circle  "
                src="/images/left1.png"
              />
            </div>
            <div className="ps-2 ">
              <h6 className="p-0 m-0">
                <span className="float-start text-muted">Rahul </span>
              </h6>

              <p className="fs-13  text-muted">
                Project : Delivering the Web Design Project
              </p>
            </div>
          </div>
          <div className="w-50 ">
            <ul className="d-flex justify-content-evenly">
              <li>
                <p>
                  <FiBriefcase />
                </p>
              </li>
              <li>
                <p>
                  <IoIosStarOutline />
                </p>
              </li>
              <li>
                <p>
                  <FiCornerUpLeft />
                </p>
              </li>
              <li>
                <p>
                  <FiCornerUpRight />
                </p>
              </li>
              <li>
                <p>2:00 pm</p>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
};
