import React from "react";

export const LeftCard = ({ img }) => {
  return (
    <>
      <div className="mb-3 w-100 mt-3">
        <div className="row mb-1  ">
          <div className="col-md-2 col-2 ">
            <img
              className="service_logo img-circle rounded-circle  "
              src={img}
            />
          </div>
          <div className="col-md-10 col-10 ">
            <h6>Service Name</h6>
            <p className="fs-14">
              I will digitize logo into embroidery dst pes ...{" "}
            </p>
          </div>
        </div>
      </div>
    </>
  );
};
