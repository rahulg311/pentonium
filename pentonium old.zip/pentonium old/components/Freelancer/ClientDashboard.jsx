import React,{useState} from "react";
import { MessageNav } from "./MessageNav";
import { MessangerCard } from "./MessangerCard";
import { MessageBox } from "./MessageBox";
import { MdAttachment, MdSend } from "react-icons/md";

export const ClientDashboard = () => {
  const [activeCircle, setactiveCircle] = useState(1)
  return (
    <>
      <div className="px-2 py-4">
        <div className="d-flex">
          <p className="fs-22 f-w-700 pt-1 ">Ongoing Projects</p>
        </div>
        <div className="row mt-4 mb-4  ">
          <div className="col-md-8 col-lg-8 col-12 p-0 mb-4  ">
            <div className="client-card  w-100 p-2 d-flex">
              <div className="w-547">
                <h5 className="m-2">eCommerce Website Design</h5>
                <p className="m-2">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Viverra vitae nibh amet interdum.Lorem ipsum dolor sit amet,
                  consectetur adipiscing elit. Viverra vitae nibh amet interdum.
                </p>
                <div className="py-5">
                  <ul className="d-flex justify-content-between">
                    <li>
                      <MdAttachment /> 8 Days Left
                    </li>
                    <li>
                      <MdAttachment /> 0.0235 ETH Left
                    </li>
                    <li>
                      <MdAttachment /> 2 Doc Left
                    </li>
                  </ul>
                </div>
                <div className="hrrow">
                  <div className={`hrrow_circle ${activeCircle == 1 || activeCircle == 2 || activeCircle == 3 || activeCircle == 4 || activeCircle == 5?"clr_grn":"clr_yellow"}`}></div>
                  <div className={`hrrow_circle circle_2 ${activeCircle == 2 || activeCircle == 3 || activeCircle == 4 || activeCircle == 5?"clr_grn":"clr_yellow"}`} onClick={()=>setactiveCircle(2)}></div>
                  <div className={`hrrow_circle circle_3 ${activeCircle == 3 || activeCircle == 4 || activeCircle == 5?"clr_grn":"clr_yellow"}`}  onClick={()=>setactiveCircle(3)}></div>
                  <div className={`hrrow_circle circle_4 ${activeCircle == 4 || activeCircle == 5?"clr_grn":"clr_yellow"}`} onClick={()=>setactiveCircle(4)}></div>
                  <div className={`hrrow_circle circle_5 ${activeCircle == 5 || activeCircle == 5?"clr_grn":"clr_yellow"}`} onClick={()=>setactiveCircle(5)}></div>
                </div>
              </div>
              <div className="w-224 ">
                <h1>t</h1>
              </div>
            </div>
          </div>
          <div className="col-md-4 col-lg-4 col-12  ">
            <MessageNav />
            <div className="hr-row p-0"></div>
            <MessageBox />
          </div>
        </div>
      </div>
    </>
  );
};
