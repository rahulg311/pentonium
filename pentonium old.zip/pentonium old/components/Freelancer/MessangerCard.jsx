import React from "react";

export const MessangerCard = () => {
  return (
    <>
      <div className=" left-box mt-4  ">
        <div className="d-flex  ">
          <div className="">
            <img
              className="service_logo img-circle1 rounded-circle   "
              src="https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/60b5e3f25f9a6_json_image_1622533106.webp"
            />
          </div>
          <div className="ms-2 ">
            <h6 className="p-0 m-0 ">
              <span className="float-start text-muted">Jim Kerry </span>
              <span className="float-end fs-13 text-muted"> 4.8 PM</span>
            </h6>{" "}
            <br />
            <h6 className="p-0 m-0">
              {" "}
              <span className="float-start">Web Development : Tre.. </span>
              <span className="float-end dot rounded-pill"></span>
            </h6>
            <br />
            <p className="fs-13 mt-1 text-muted">
              Hi, my name is Jim, I have reached out , proposal for your
              project.{" "}
            </p>
          </div>
        </div>
        <div className="hr-row1  ms-4"></div>
      </div>
    </>
  );
};
