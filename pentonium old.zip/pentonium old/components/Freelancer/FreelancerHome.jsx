import React from "react";
import { AiFillCaretUp } from "react-icons/ai";

import { HomeCard } from "./HomeCard";
import { RecentCard } from "./RecentCard";
import { Table } from "./Table";
import { LeftCard } from "./LeftCard";

export const FreelancerHome = () => {
  return (
    <>
      <div className="row mt-4">
        <div className="col-md-8 col-12 col-lg-8">
          <h5 className="p-1 fw-bold fs-23">Statistics</h5>
          <div className="row mt-4 mb-4">
            <div className="col-md-3 mb-2 col-12 col-lg-3">
              <HomeCard
                name="Money Earned"
                para="ETH"
                number="0.05626"
                per="1.3%"
                bkg_clr="color-p1"
                icon={true}
              />
            </div>
            <div className="col-md-3 mb-2 col-12 col-lg-3">
              <HomeCard
                name="Ongoing projects"
                para="Open"
                number="0.05626"
                bkg_clr="color-p2"
              />
            </div>
            <div className="col-md-3 mb-2 col-12 col-lg-3">
              <HomeCard
                name="Closed projects"
                para="Closed"
                number="0.05626"
                bkg_clr="color-p3"
              />
            </div>
            <div className="col-md-3 mb-2 col-12 col-lg-3">
              <HomeCard
                name="Services Posted"
                para="Services"
                number="0.05626"
                bkg_clr="color-p4"
              />
            </div>
          </div>
          <h5 className="p-1 fw-bold fs-23 black-c ">Ongoing Projects</h5>
          <div div className="px-2 mt-4 h-50 overflow-auto" id="style-2">
            <Table />
          </div>
        </div>
        <div className="col-md-4 col-12 col-lg-4 ">
          <h5 className="p-1 fw-bold fs-23">Recent Activity</h5>
          <div className="mb-3 w-100">
            <RecentCard />
          </div>
          <div className="mb-3 w-100">
            <RecentCard />
          </div>
          <h5 className="p-1 pb-3 fw-bold fs-23">Order Purchased</h5>

          <LeftCard img="https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/60b5e3f25f9a6_json_image_1622533106.webp" />
          <LeftCard img="/images/left2.png" />
          <LeftCard img="/images/left1.png" />
        </div>
      </div>
    </>
  );
};
