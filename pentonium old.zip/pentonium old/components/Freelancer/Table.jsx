import React from "react";

export const Table = () => {
  return (
    <>
      <table class="table">
        <thead>
          <tr>
            <th scope="col" className="fsr-12">
              Service Name
            </th>
            <th scope="col" className="fsr-12 td-w">
              Date
            </th>
            <th scope="col" className="fsr-12 td-w">
              End Date
            </th>
            <th scope="col" className="fsr-12 td-w">
              Status
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  ">In Progress</button>
            </td>
          </tr>
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  ">In Progress</button>
            </td>
          </tr>{" "}
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  b-color-p ">Done</button>
            </td>
          </tr>{" "}
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  b-color-p ">Done</button>
            </td>
          </tr>{" "}
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  ">In Progress</button>
            </td>
          </tr>
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  ">In Progress</button>
            </td>
          </tr>{" "}
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  b-color-p ">Done</button>
            </td>
          </tr>{" "}
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  b-color-p ">Done</button>
            </td>
          </tr>{" "}
          <tr>
            <td scope="row" className="fsr-12 td-w1  ">
              I will digitize logo into embroidery pes in 1hr
            </td>
            <td className="fsr-12 td-w">01 -03 - 20</td>
            <td className="fsr-12 td-w">11 -03 - 20</td>
            <td>
              <button className="btnn1 r-btnn1  ">In Progress</button>
            </td>
          </tr>
          {/* <tr >
      <td scope="row">I will digitize logo into embroidery pes in 1hr</td>
      <td>01 -03 - 20</td>
      <td>11 -03 - 20</td>
      <td> <button className="btnn1 b-color-p">Done</button></td>
    </tr>

    <tr >
      <td scope="row">I will digitize logo into embroidery pes in 1hr</td>
      <td>01 -03 - 20</td>
      <td>11 -03 - 20</td>
      <td className=""><button className="b-color-p btnn1">Done</button></td>
    </tr>

    <tr >
      <td scope="row">I will digitize logo into embroidery pes in 1hr</td>
      <td>01 -03 - 20</td>
      <td>11 -03 - 20</td>
      <td><button className="btnn1">In Progress</button></td>
    </tr>

    <tr >
      <td scope="row">I will digitize logo into embroidery pes in 1hr</td>
      <td>01 -03 - 20</td>
      <td>11 -03 - 20</td>
      <td><button className="btnn1">In Progress</button></td>
    </tr>

    <tr >
      <td scope="row">I will digitize logo into embroidery pes in 1hr</td>
      <td>01 -03 - 20</td>
      <td>11 -03 - 20</td>
      <td><button className="b-color-p btnn1">Done</button></td>
    </tr>

    <tr >
      <td scope="row">I will digitize logo into embroidery pes in 1hr</td>
      <td>01 -03 - 20</td>
      <td>11 -03 - 20</td>
      <td><button className="b-color-p btnn1">Done</button></td>
    </tr> */}
        </tbody>
      </table>
    </>
  );
};
