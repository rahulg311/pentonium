import React from "react";
import { MdAttachment, MdSend } from "react-icons/md";

export const MessageBox = () => {
  return (
    <>
      {" "}
      <div className="row bg-gray-1 h-90 position-relative  d-flex rounded-3  flex-column  ">
        {/* <div className="hr-row"></div> */}

        <div class="">
          <div class="incoming text-start">
            <div class="bubble">
              <div className="d-flex w-100 ">
                <img
                  className="service_logo img-circle1 rounded-circle  "
                  src="https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/60b5e3f25f9a6_json_image_1622533106.webp"
                />

                <p className="p-2 ">Hey, Father's Day is coming up..</p>
              </div>
            </div>
          </div>
          <div class="outgoing text-end">
            <div class="bubble lower">
              <div className="d-flex w-100 ">
                <p>
                  Well you should get your Dad a cologne. Here smell it. Oh
                  wait! ...
                </p>
                <img
                  className="service_logo img-circle1 rounded-circle  "
                  src="/images/left1.png"
                />
              </div>
            </div>
          </div>
          <div class="typing">
            <div class="bubble">
              <div class="ellipsis dot_1"></div>
              <div class="ellipsis dot_2"></div>
              <div class="ellipsis dot_3"></div>
            </div>
          </div>
        </div>
        <div class="foot  position-absolute bg-gray  bottom-0 p-2  d-flex bg-gray ">
          <span className=" pe-2 fs-18">
            <MdAttachment />
          </span>
          <input
            type="text"
            class="msg rounded-pill border-0 p-1  "
            placeholder="    Type a message..."
          />
          <span className=" ps-2 fs-18">
            <MdSend />
          </span>
        </div>
      </div>
    </>
  );
};
