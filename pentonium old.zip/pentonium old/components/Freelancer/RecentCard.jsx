import React from "react";

export const RecentCard = () => {
  return (
    <>
      <div className="box-2 bg-dange mt-4 px-2">
        <div className="row mb-1  ">
          <div className="col-md-2 col-2 ">
            <img
              className="service_logo img-circle rounded-circle  "
              src="https://d3jmn01ri1fzgl.cloudfront.net/photoadking/webp_thumbnail/60b5e3f25f9a6_json_image_1622533106.webp"
            />
          </div>
          <div className="col-md-10 col-10 ">
            <h6>Service Name</h6>
            <p className="fs-14">
              I will digitize logo into embroidery dst pes ...
            </p>
          </div>
        </div>
        <h5 className="fs-14">Message:</h5>
        <p className="fs-14">
          Statistics is the discipline that concerns the collection,
          organization, analysis, interpretation, and presentation of data. In
          applying statistics to ...
        </p>
        <button className="btn-2 fs-13">Check Order</button>
      </div>
    </>
  );
};
