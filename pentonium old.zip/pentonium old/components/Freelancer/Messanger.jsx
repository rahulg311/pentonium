import React from "react";
import { MessageNav } from "./MessageNav";
import { MessangerCard } from "./MessangerCard";
import { MessageBox } from "./MessageBox";

export const Messanger = () => {
  return (
   <>
     <div className="px-2 py-4">
        <div className="d-flex">
          <button className="btnn2 fs-20">Inbox</button>
          <p className="fs-20 ps-4 p-0 pt-1 ">Discussions</p>
        </div>
        <div className="row mt-4 mb-4  ">
          <div className="col-md-3 col-lg-3 col-12 p-0 mb-4 ">
            <form class="w-96  mb-3 mt-2  ">
              <input
                className="form-control me-2 border-0 bg-gray "
                type="search"
                placeholder="Search"
                aria-label="Search"
              />
            </form>
            <div className="h-90 overflow-auto" id="style-2">
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
              <MessangerCard />
            </div>
          </div>
          <div className="col-md-9 col-lg-9 col-12  ">
            <MessageNav />
            <div className="hr-row p-0"></div>
            <MessageBox />
          </div>
        </div>
      </div>
   </>
  );
};
