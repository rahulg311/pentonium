import React from "react";
import { AiFillCaretUp } from "react-icons/ai";

export const HomeCard = ({ name, para, number, per, bkg_clr,icon=false }) => {
  return (
    <>
      <div className={`boxx ${bkg_clr} w-r-100`} >
        <h6 className="money-earned money-earned p-1 ms-3 pt-4 f-w-600 fs-14 ">
          {name}
        </h6>
        <div className="row mt-4">
          <div className="col-md-12   ">
            <p className="eth-p mt-5 float-start ms-3 f-w-700 fs-20 black-c">
              {para}
            </p>

            <p className="triangle float-end mt-5 pe-4 ">
              <span className="color-p f-w-600 fs-14">
                {icon&&
                <AiFillCaretUp />
                }
                {per}
              </span>
            </p>
          </div>
        </div>
        {/* <p className=" ">0.05626</p> */}
        <small className="ms-3 f-w-700 fs-20 black-c"> {number}</small>
      </div>
    </>
  );
};
