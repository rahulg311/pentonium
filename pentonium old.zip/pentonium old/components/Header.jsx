import 'bootstrap/dist/css/bootstrap.css';
import Image from 'next/Image'
const Header = () => {
    return (<>
        <div className='container'>
            <div className='row'>
                <div className='col mt-2'>
                    <Image src={'/fiverr logo.png'} alt="Logo" width="100%" height="30px" />
                </div>
                <div className='col mt-1 d-flex justify-content-end'>
                
                    <button className="  btnn1">Connect</button>
                </div>
            </div>
        </div>
    </>);
}

export default Header;