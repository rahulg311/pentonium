import { Component } from "react";
import Footer from "../Footer";
import Header from "../Header";

class MainLayout extends Component {
  state = {};
  render() {
    return (
      <>
        <Header />
        {this.props.children}
        <Footer />
      </>
    );
  }
}

export default MainLayout;
