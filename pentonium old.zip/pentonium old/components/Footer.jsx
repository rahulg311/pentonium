import 'font-awesome/css/font-awesome.min.css';

const Footer = () => {
    return (<>
        <div className='container'>
            <div className='row'>
                <div className='col-md-3'>
                    <h4 className='footer-nav-title'>Categories</h4>
                    <ul className='footer-nav'>
                        <li>Help & Support</li>
                        <li>Marshal</li>
                        <li>Help & Support</li>
                        <li>Marshal</li>
                        <li>Service Provider</li>
                        <li>Client</li>
                        <li>Help & Support</li>
                        <li>Marshal</li>
                        <li>Service Provider</li>
                        <li>Client</li>
                    </ul>
                </div>
                <div className='col-md-2'>
                    <h4 className='footer-nav-title'>About</h4>
                    <ul className='footer-nav'>
                        <li>Telegram</li>
                        <li>Blog</li>
                        <li>Github</li>
                        <li>Telegram</li>
                        <li>Blog</li>
                        <li>Github</li>
                    </ul>
                </div>
                <div className='col-md-3'>
                    <h4 className='footer-nav-title'>Support</h4>
                    <ul className='footer-nav'>
                        <li>Help & Support</li>
                        <li>Marshal</li>
                        <li>Service Provider</li>
                        <li>Client</li>
                    </ul>
                </div>
                <div className='col-md-2'>
                    <h4 className='footer-nav-title'>Community</h4>
                    <ul className='footer-nav'>
                        <li>Telegram</li>
                        <li>Blog</li>
                        <li>Github</li>
                        <li>Telegram</li>
                        <li>Blog</li>
                        <li>Github</li>
                        <li>Telegram</li>
                        <li>Blog</li>
                        <li>Github</li>
                    </ul>
                </div>
                <div className='col-md-2'>
                    <h4 className='footer-nav-title'>More For You</h4>
                    <ul className='footer-nav'>
                        <li>Telegram</li>
                        <li>Blog</li>
                        <li>Github</li>
                    </ul>
                </div>
            </div>
        </div>
        <div className="container-fluid">
            <div className='footer row p-4'>
                <div className='col-md-2'>
                    <img src='/fiverr logo.png' height="30px" />
                </div>
                <div className='col-md-7'>
                    Copyright @ 2010-2021 Pantonium. All rights reserved
                </div>
                <div className='col-md-3 row'>
                    <div className="col-md-4">
                        Follow Us
                    </div>
                    <div className="col-md-2">
                        <i className="fa fa-telegram fa-2x"></i>
                    </div>
                    <div className="col-md-2">

                        <i class="fa fa-globe fa-2x"></i>
                    </div>
                    <div className="col-md-2">
                        <i className="fa fa-github fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </>);
}

export default Footer;