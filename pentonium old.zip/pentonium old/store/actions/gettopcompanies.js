import { GET_TOP_COMPANY } from "../redux_constatnt";

export const getCompanies = () => async (dispatch) => {
    try {
        const response = await fetch(END_POINT + "URL", {
            method: 'POST',
        });
        const json = await response.json();
        await dispatch({ type: GET_TOP_COMPANY, data: json });
    } catch (e) {
        console.log(e);
    }
};
