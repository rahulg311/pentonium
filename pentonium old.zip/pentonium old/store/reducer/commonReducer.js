import { GET_TOP_COMPANY } from "../redux_constatnt";



const initialState = {
    data: [],
    loading: false,
    error: null
};

export default function (state = initialState, action) {
    switch (action.type) {
        case GET_TOP_COMPANY:
            return {
                ...state,
                data: action.data
            };
        default:
            return state;
    }
}


