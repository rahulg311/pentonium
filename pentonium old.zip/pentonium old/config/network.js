export default {
    4: {
        
        name: "rinkeby",
        publicRpc: "https://rinkeby.infura.io/v3/b5ef34114e4747759f1cce670f02b2b7",

        chainName: "rinkeby",
        
        contracts: {
            agreementToken: {
                address: "0x29fdb41e85Dd6b9Bc5E55082D0e6ea89951030e8",
                abi: require(__dirname+"/../data/abi/Agreement.json")
            },
            listing: { 
                address: "0xA276f40147a8C4d66fc0A63895DfC4d329Aaba1c",
                abi: require(__dirname+"/../data/abi/AgreementListing.json")
            }
        }
    },
}